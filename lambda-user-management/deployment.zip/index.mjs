import { clerkClient } from '@clerk/backend';

export const handler = async (event) => {
    try {
        console.log('Lambda function started');
        console.log('Event:', JSON.stringify(event, null, 2));

        // 1. CORS预检请求处理
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: ''
            };
        }

        // 2. 环境变量检查
        if (!process.env.CLERK_SECRET_KEY) {
            console.error('CLERK_SECRET_KEY not found in environment variables');
            return {
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ 
                    error: 'Server configuration error',
                    details: 'Missing CLERK_SECRET_KEY'
                })
            };
        }

        // 3. 权限验证 (暂时注释掉，方便测试)
        // const authHeader = event.headers.Authorization || event.headers.authorization;
        // if (!authHeader || !authHeader.startsWith('Bearer ')) {
        //     return {
        //         statusCode: 401,
        //         headers: {
        //             'Access-Control-Allow-Origin': '*',
        //             'Content-Type': 'application/json'
        //         },
        //         body: JSON.stringify({ error: 'Missing or invalid authorization header' })
        //     };
        // }

        // 4. 路由处理
        const method = event.httpMethod;
        const path = event.path || event.pathParameters?.proxy || '';

        console.log(`Processing ${method} ${path}`);

        // 获取所有用户
        if (method === 'GET' && (path === '/users' || path === '')) {
            console.log('Fetching users from Clerk...');
            
            const users = await clerkClient.users.getUserList();
            console.log(`Found ${users.length} users`);

            // 格式化用户数据，包含权限信息
            const formattedUsers = users.map(user => ({
                id: user.id,
                email: user.primaryEmailAddress?.emailAddress || 'No email',
                firstName: user.firstName || '',
                lastName: user.lastName || '',
                createdAt: user.createdAt,
                modules: user.publicMetadata?.modules || [],
                status: user.publicMetadata?.status || 'pending'
            }));

            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    success: true,
                    users: formattedUsers,
                    count: formattedUsers.length
                })
            };
        }

        // 更新用户模块权限
        if (method === 'PUT' && path.includes('/modules')) {
            const userId = event.pathParameters?.userId;
            if (!userId) {
                return {
                    statusCode: 400,
                    headers: {
                        'Access-Control-Allow-Origin': '*',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ error: 'Missing userId parameter' })
                };
            }

            const body = JSON.parse(event.body || '{}');
            const { modules = [], status = 'approved' } = body;

            console.log(`Updating user ${userId} modules:`, modules);

            await clerkClient.users.updateUserMetadata(userId, {
                publicMetadata: {
                    modules: modules,
                    status: status,
                    updatedAt: new Date().toISOString()
                }
            });

            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    success: true,
                    message: `User ${userId} modules updated`,
                    modules: modules
                })
            };
        }

        // 未匹配的路由
        return {
            statusCode: 404,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                error: 'Endpoint not found',
                method: method,
                path: path
            })
        };

    } catch (error) {
        console.error('Lambda function error:', error);
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                error: 'Internal server error',
                details: error.message
            })
        };
    }
};